pay_to_nick = True # Оплата по нику или же нет

number = '79940081161' # Номер киви
qiwi = '822c2a757f42c08fcec4a7c3cc6b6f4b' # токен киви
nick = 'VLADONXHACKER' # Ваш ник киви
